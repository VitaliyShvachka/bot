<b>Новая ошибка</b>
Текст: <i>{{$e->getMessage()}}</i>
Файл: <i>{{$e->getFile()}}</i>
Строка: <i>{{$e->getLine()}}</i>
